
    /** \brief Suma los 2 numeros ingresados.
     *
     * \param n1 el primer numero ingresado.
     * \param n2 el segundo numero ingresado.
     * \return es suma de ambos numeros ingresados.
     */

    float     suma       (float n1, float n2);
    /** \brief Resta los 2 numeros ingresados.
     *
     * \param n1 el primer numero ingresado.
     * \param n2 el segundo numero ingresado.
     * \return es la resta de ambos numeros ingresados.
     */
    float     resta      (float n1, float n2);
    /** \brief divide los 2 numeros ingresados.
     *
     * \param n1 el primer numero ingresado.
     * \param n2 el segundo numero ingresado.
     * \return es la division de ambos numeros ingresados.
     */

    float     division     (float n1, float n2);
    /** \brief multiplica los 2 numeros ingresados.
     *
     * \param n1 el primer numero ingresado.
     * \param n2 el segundo numero ingresado.
     * \return es la multiplicacion de ambos numeros ingresados.
     */

    float     multiplicacion (float, float);
    /** \brief multiplica el numero ingresado por sus numeros anteriores hasta llegar al numero uno.
     *
     * \param n1 el primer numero ingresado.
     * \return es el factorial del numero ingresado.
     */


    float     factorial   (float n1);



